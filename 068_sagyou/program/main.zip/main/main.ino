const int sensorPin = A0;
const int ledPin = 13;
const int threshold = 600;
const int targetCount = 21;

boolean isLightOn = false;
int currentCount = 0;
unsigned long lastLightTime = 0;
const unsigned long timeout = 1000;

void setup()
{
    Serial.begin(115200);
    pinMode(ledPin, OUTPUT);
}

void loop()
{
    int sensorValue = analogRead(sensorPin);
    unsigned long currentTime = millis();

    if (sensorValue > threshold && isLightOn == false)
    {
        isLightOn = true;
        currentCount++;
        digitalWrite(ledPin, HIGH);
        lastLightTime = currentTime;
        delay(50);
    }
    else if (sensorValue <= threshold && isLightOn == true)
    {
        isLightOn = false;
        digitalWrite(ledPin, LOW);
        delay(50);
    }

    if (currentCount > 0 && (currentTime - lastLightTime > timeout))
    {
        if (currentCount == targetCount)
        {
            Serial.write(255); // 一致していればバイナリデータとして「255」を送信
        }
        currentCount = 0;
    }
}