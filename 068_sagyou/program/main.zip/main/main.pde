//分割

import ddf.minim.*;
import ddf.minim.ugens.*;
import ddf.minim.effects.*;
import processing.serial.*;

Minim minim;
AudioOutput out;
WaveVisualizer vis;   //ビジュアライザー用
Serial myPort;        //シリアル通信用
boolean hasPlayed = false; // 既に演奏したか？を記憶するフラグ

void setup() {
  size(600, 300);     //ウィンドウサイズ統一
  minim = new Minim(this);
  out = minim.getLineOut();

  // 設定済みのシリアルポート名
  String portName = "ここ変更"; // ※ご自身の環境に合わせて設定されているポート名
  
  // 指定したポート名で接続
  myPort = new Serial(this, portName, 115200);
  
  out.setTempo(120); 
  tromboneWave = WavetableGenerator.gen10(
    4096,
    new float[] {1.0f, 0.0f, 0.32f, 0.2f, 0.1f}
  );
  
  vis = new WaveVisualizer(out);
}

void draw() {
  background(0);
  // 「音の担当」が鳴らしている out を、「見た目の担当」に渡して描画
  vis.drawWave(out); 

  // 波形描画
  stroke(0, 255, 0);
  strokeWeight(2);
  for(int i = 0; i < out.bufferSize() - 1; i++) {
    line(i, 150 + out.left.get(i)*100, i+1, 150 + out.left.get(i+1)*100);
  }
  
  // 状態に合わせて文字色を変更
  if (hasPlayed == false) {
    fill(255);
  } else {
    fill(255, 100, 100); // 再生後は赤文字にする
  }
  
  // 画面に現在の状態を表示
  text(hasPlayed ? "Status: Played (Press 'R' to Reset)" : "Status: Waiting for Arduino (21 flashes)", 20, 30);
}

// 【修正】キーボード入力を1つの関数に統合
void keyPressed() {
  if (key == 'p' || key == 'P') {
    playSong();
    hasPlayed = true;
  }
  if (key == 'r' || key == 'R') {
    hasPlayed = false; // フラグを未演奏に戻す
    println(">>> システムをリセットしました.再び待機します．");
  }
}

// 【修正】データ受信はここに集約（draw内からは削除）
void serialEvent(Serial p) {
  while (p.available() > 0) {
    int inByte = p.read();
    
    // Arduinoからトリガー「255」を受け取り、かつまだ演奏していない時だけ鳴らす
    if (inByte == 255 && hasPlayed == false) {
      playSong();
      hasPlayed = true; 
      //println(">>> Arduinoから255を受信: 演奏を開始します！");
    }
  }
}